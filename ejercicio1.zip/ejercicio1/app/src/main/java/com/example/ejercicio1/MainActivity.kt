package com.example.ejercicio1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val calcularButton = findViewById<Button>(R.id.calcularButton)
        val resultadoTextView = findViewById<TextView>(R.id.resultadoTextView)

        calcularButton.setOnClickListener {
            val nombre = findViewById<EditText>(R.id.nombreEditText).text.toString()
            val nota1 = findViewById<EditText>(R.id.nota1EditText).text.toString().toDoubleOrNull()
            val nota2 = findViewById<EditText>(R.id.nota2EditText).text.toString().toDoubleOrNull()
            val nota3 = findViewById<EditText>(R.id.nota3EditText).text.toString().toDoubleOrNull()
            val nota4 = findViewById<EditText>(R.id.nota4EditText).text.toString().toDoubleOrNull()
            val nota5 = findViewById<EditText>(R.id.nota5EditText).text.toString().toDoubleOrNull()

            // Validación de que las notas estén entre 0 y 10
            if (nota1 == null || nota2 == null || nota3 == null || nota4 == null || nota5 == null ||
                nota1 !in 0.0..10.0 || nota2 !in 0.0..10.0 || nota3 !in 0.0..10.0 || nota4 !in 0.0..10.0 || nota5 !in 0.0..10.0) {
                Toast.makeText(this, "Por favor, ingrese notas válidas entre 0 y 10.", Toast.LENGTH_SHORT).show()
            } else {
                val promedio = (nota1 * 0.15 + nota2 * 0.15 + nota3 * 0.20 + nota4 * 0.25 + nota5 * 0.25)
                val estado = if (promedio >= 6) "aprobó" else "reprobó"
                resultadoTextView.text = "$nombre, tu nota final es $promedio y $estado."
            }
        }
    }
}
